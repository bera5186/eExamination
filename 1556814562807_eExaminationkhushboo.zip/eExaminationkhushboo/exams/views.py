from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from . models import UserRegistration, Contact, MathsQuestion, AptitudeQuestions


# Create your views here.
def index(request):

    return render(request, 'index.html')

def about(request):

    return render(request, 'about.html')

def contact(request):

    if request.method == 'POST':
        name = request.POST["username"]
        email = request.POST["useremail"]
        number = request.POST["userphone"]
        subject = request.POST["usersubject"]
        message = request.POST["usermessage"]
        contact = Contact()
        contact.subject = subject
        contact.email = email
        contact.name = name
        contact.contact = number
        contact.message = message
        contact.save()

        return redirect(login)



    return render(request, 'contact.html')

def courses(request):

    return render(request, 'courses.html')

def login(request) :
    
    '''if request.method == 'GET':
        uemail = request.GET.get('email')
        upassword = request.GET.get('password')

        search_feild1 = ['email']
        search_feild2 = ['password']

        semail  = UserRegistration.objects.filter(search_filter(search_feild1, uemail))
        spassword = UserRegistration.objects.filter(search_filter(search_feild2, upassword))

        


        print(semail, spassword)'''
        
        







    return render(request, 'login.html')

def price(request):

    return render(request, 'price.html')

def projects(request):

    return render(request, 'projects.html')

def signup(request):

    if request.method == 'POST':
        email = request.POST["email"]
        name = request.POST["username"]
        password = request.POST["password"]
        signUp = UserRegistration()
        
        signUp.email = email
        signUp.username = name
        signUp.password = password
        signUp.save()

        return redirect(login)

    return render(request, 'signup.html')




    

def sidebar(request):

    return render(request, 'sidebar-right.html')

def maths_examination(request):

    context = {
        'questions' : MathsQuestion.objects.all()
    }

    return render(request, 'maths.html', context=context)

def apti_exam(request):

    context = {
        'questions': AptitudeQuestions.objects.all()
    }

    return render(request, 'apti.html', context=context)

def result(request):

    return render(request, 'result.html')

def user_logged_in(request):

    return render(request, 'index_with_login.html')