from django.db import models
import uuid

# Create your models here.
class AptitudeQuestions(models.Model):
    question = models.TextField(max_length=1000)
    qid = models.UUIDField(null=False, default=uuid.uuid4)
    optiona = models.CharField(max_length=100, default='')
    optionb = models.CharField(max_length=100, default='')
    optionc = models.CharField(max_length=100, default='')
    optiond = models.CharField(max_length=100, default='')

    qid1 = models.CharField(max_length=30, default='')
    qid2 = models.CharField(max_length=30, default='')
    qid3 = models.CharField(max_length=30, default='')
    qid4 = models.CharField(max_length=30, default='')


    def __str__(self):
        return self.question


class MathsQuestion(models.Model):
    
    question = models.TextField(max_length=1000)
    qid = models.UUIDField(null=False, default=uuid.uuid4)
    optiona = models.CharField(max_length=100, default='')
    optionb = models.CharField(max_length=100, default='')
    optionc = models.CharField(max_length=100, default='')
    optiond = models.CharField(max_length=100, default='')


    qid1 = models.CharField(max_length=30)
    qid2 = models.CharField(max_length=30)
    qid3 = models.CharField(max_length=30)
    qid4 = models.CharField(max_length=30)


    def __str__(self):
        return self.question

""" class Exam(models.Model):

    examName = models.CharField(max_length=1000)
    aptQ = models.ForeignKey(AptitudeQuestions, on_delete=models.SET_NULL, null=True)
    mathsQ = models.ForeignKey(MathsQuestions, on_delete=models.SET_NULL, null=True)
    duration = models.CharField(max_length=4, help_text='Enter Duration in minutes') 

    def __str__(self):
        return self.examName"""

class UserRegistration(models.Model):
    username = models.CharField(max_length=1000)
    email = models.EmailField(max_length=254)
    password = models.CharField(max_length=15)

    def __str__(self):
        return self.username

class Contact(models.Model):
    name = models.CharField(max_length=1000)
    email = models.EmailField()
    contact = models.IntegerField()
    subject = models.CharField(max_length=200)
    message = models.TextField()

    def __str__(self):
        return self.subject

