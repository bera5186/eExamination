from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('courses/', views.courses, name='courses'),
    path('login/', views.login, name='login'),
    path('price/', views.price, name='price'),
    path('projects/', views.projects, name='projects'),
    path('signup/', views.signup, name='signup'),
    path('sidebar/', views.sidebar, name='sidebar'),
    path('maths_exam/', views.maths_examination, name='maths_exam'),
    path('apti_exam/', views.apti_exam, name='apti_exam'),
    path('result/', views.result, name='result'),
    path('logged_in/', views.user_logged_in, name='logged'),
]

