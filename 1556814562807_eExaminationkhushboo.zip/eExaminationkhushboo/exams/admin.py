from django.contrib import admin
from . models import MathsQuestion, AptitudeQuestions, UserRegistration, Contact
# Register your models here.

admin.site.register(MathsQuestion)
admin.site.register(AptitudeQuestions)
admin.site.register(UserRegistration)
admin.site.register(Contact)