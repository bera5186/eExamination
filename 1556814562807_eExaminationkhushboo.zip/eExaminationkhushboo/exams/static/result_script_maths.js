function clickSubmit() {

    localStorage.clear();

    var originalAnswers = ['A', 'B', 'B', 'D', 'A', 'B', 'C', 'A', 'D', 'C'];
    localStorage.setItem('originalanswers', JSON.stringify(originalAnswers));
    var answers = [];
    
    if(document.getElementById('q1a1').checked){
        answers.push(document.getElementById('q1a1').value)
    } 
    else if(document.getElementById('q1a2').checked) {
        answers.push(document.getElementById('q1a2').value)
    } 
    else if (document.getElementById('q1a3').checked) {
        answers.push(document.getElementById('q1a3').value)
    } 
    else if (document.getElementById('q1a4').checked){
        answers.push(document.getElementById('q1a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q2a1').checked){
        answers.push(document.getElementById('q2a1').value)
    } 
    else if(document.getElementById('q2a2').checked) {
        answers.push(document.getElementById('q2a2').value)
    } 
    else if (document.getElementById('q2a3').checked) {
        answers.push(document.getElementById('q2a3').value)
    } 
    else if (document.getElementById('q2a4').checked){
        answers.push(document.getElementById('q2a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q3a1').checked){
        answers.push(document.getElementById('q3a1').value)
    } 
    else if(document.getElementById('q3a2').checked) {
        answers.push(document.getElementById('q3a2').value)
    } 
    else if (document.getElementById('q3a3').checked) {
        answers.push(document.getElementById('q3a3').value)
    } 
    else if (document.getElementById('q3a4').checked){
        answers.push(document.getElementById('q3a4').value)
    } 
    else {
        answers.push('X')
    }
    
    if(document.getElementById('q4a1').checked){
        answers.push(document.getElementById('q4a1').value)
    } 
    else if(document.getElementById('q4a2').checked) {
        answers.push(document.getElementById('q4a2').value)
    } 
    else if (document.getElementById('q4a3').checked) {
        answers.push(document.getElementById('q4a3').value)
    } 
    else if (document.getElementById('q4a4').checked){
        answers.push(document.getElementById('q4a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q5a1').checked){
        answers.push(document.getElementById('q5a1').value)
    } 
    else if(document.getElementById('q5a2').checked) {
        answers.push(document.getElementById('q5a2').value)
    } 
    else if (document.getElementById('q5a3').checked) {
        answers.push(document.getElementById('q5a3').value)
    } 
    else if (document.getElementById('q5a4').checked){
        answers.push(document.getElementById('q5a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q6a1').checked){
        answers.push(document.getElementById('q6a1').value)
    } 
    else if(document.getElementById('q6a2').checked) {
        answers.push(document.getElementById('q6a2').value)
    } 
    else if (document.getElementById('q6a3').checked) {
        answers.push(document.getElementById('q6a3').value)
    } 
    else if (document.getElementById('q6a4').checked){
        answers.push(document.getElementById('q6a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q7a1').checked){
        answers.push(document.getElementById('q7a1').value)
    } 
    else if(document.getElementById('q7a2').checked) {
        answers.push(document.getElementById('q7a2').value)
    } 
    else if (document.getElementById('q7a3').checked) {
        answers.push(document.getElementById('q7a3').value)
    } 
    else if (document.getElementById('q7a4').checked){
        answers.push(document.getElementById('q7a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q8a1').checked){
        answers.push(document.getElementById('q8a1').value)
    } 
    else if(document.getElementById('q8a2').checked) {
        answers.push(document.getElementById('q8a2').value)
    } 
    else if (document.getElementById('q8a3').checked) {
        answers.push(document.getElementById('q8a3').value)
    } 
    else if (document.getElementById('q8a4').checked){
        answers.push(document.getElementById('q8a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q9a1').checked){
        answers.push(document.getElementById('q9a1').value)
    } 
    else if(document.getElementById('q9a2').checked) {
        answers.push(document.getElementById('q9a2').value)
    } 
    else if (document.getElementById('q9a3').checked) {
        answers.push(document.getElementById('q9a3').value)
    } 
    else if (document.getElementById('q9a4').checked){
        answers.push(document.getElementById('q9a4').value)
    } 
    else {
        answers.push('X')
    }

    if(document.getElementById('q10a1').checked){
        answers.push(document.getElementById('q10a1').value)
    } 
    else if(document.getElementById('q10a2').checked) {
        answers.push(document.getElementById('q10a2').value)
    } 
    else if (document.getElementById('q10a3').checked) {
        answers.push(document.getElementById('q10a3').value)
    } 
    else if (document.getElementById('q10a4').checked){
        answers.push(document.getElementById('q10a4').value)
    } 
    else {
        answers.push('X')
    }
    var correct = 0, percent;
    for(var i=0; i < answers.length; i++){
        if(answers[i] == originalAnswers[i]) {
            localStorage.setItem('q'+i, 'correct') ;
            correct = correct + 1;
        } else {
            localStorage.setItem('q'+i, 'wrong') ;
        }
    }

    percent = (correct/10) * 100;
    localStorage.setItem('percent', percent);
    localStorage.setItem("useranswer", JSON.stringify(answers));


    console.log(answers);
    //window.location.replace("file:///home/rahul/Desktop/localstorage/result.html");

    window.location = "http://127.0.0.1:5555/result/";

    
}