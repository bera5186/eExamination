/* /* var p = localStorage.getItem('percent');
var x = document.getElementById('progress');
x.innerText = p;
//var percent = document.querySelector('#percentage');
console.log(p); 

var p = localStorage.getItem('percent');
var ele = document.getElementById('#h1');
console.log(ele); */