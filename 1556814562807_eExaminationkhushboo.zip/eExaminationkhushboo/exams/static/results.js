var per = localStorage.getItem('percent');
var ele = document.getElementById('h1');
var prog = document.getElementById('progress');

if (per < 40) {
    prog.style.backgroundColor = 'red';
    ele.innerText = 'Percentage : '+per+' % ' + '(Fail)';
} else {
    prog.style.backgroundColor = 'green';
    ele.innerText = 'Percentage : '+per+' % ' + '(Pass)';
}

var percentage = per + '%';

prog.style.width = percentage;




console.log(ele);