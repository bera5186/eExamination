var userObj = [
    {
        'username':'Khushboo',
        'password': '<3'
    },
    {
        'username': 'Krishna',
        'password': 'L18CSE06'
    },
    {
        'username': 'Mahima',
        'password': 'Sheisbest'
    },
    {
        'username': 'Moksh',
        'password': '*_*'
    }
];

function login() {
    
    var username = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var flag = 0;

    console.log(username);
    console.log(password)

    for(var i =0; i < userObj.length; i++ ){
        if(username == userObj[i].username && password == userObj[i].password) {
            flag = 1;
            console.log('signed in')
            break;
        }
    }

    if(flag == 1)
    {
        window.location = '127.0.0.1:5555/logged_in/';
    }

    else {
        alert('Username or password is incorrect !! ');
    }

}

function signup() {

    var username = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    userObj.push({
        'username' : username,
        'password' : password
    });

    window.location = '127.0.0.1:5555/login/'

}